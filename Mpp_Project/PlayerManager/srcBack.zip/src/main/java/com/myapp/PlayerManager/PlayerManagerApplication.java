package com.myapp.PlayerManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlayerManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlayerManagerApplication.class, args);
	}
}
